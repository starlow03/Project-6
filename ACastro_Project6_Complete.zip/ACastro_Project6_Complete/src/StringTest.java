import org.junit.Test;
import static org.junit.Assert.*;
 
/**
 * Class tests four methods from the java.lang.String class:
 * length(), charAt(), substring(), and indexOf().
 */
public class StringTest {
 
    
    // Tests for length()
    
 
    /**
     * Tests that length() returns the correct number of characters
     * in a normal word.
     */
    @Test
    public void testLengthNormalWord() {
        String s = "Hello";
        assertEquals(5, s.length());
    }
 
    /**
     * Tests that length() returns 0 for an empty string.
     */
    @Test
    public void testLengthEmptyString() {
        String s = "";
        assertEquals(0, s.length());
    }
 
    /**
     * Tests that length() counts spaces as characters.
     */
    @Test
    public void testLengthWithSpaces() {
        String s = "Hello World";
        assertEquals(11, s.length());
    }
 
    // -------------------------------------------------------
    // Tests for charAt()
    // -------------------------------------------------------
 
    /**
     * Tests that charAt() returns the correct first character
     * at index 0.
     */
    @Test
    public void testCharAtFirstCharacter() {
        String s = "Java";
        assertEquals('J', s.charAt(0));
    }
 
    /**
     * Tests that charAt() returns the correct last character.
     */
    @Test
    public void testCharAtLastCharacter() {
        String s = "Java";
        assertEquals('a', s.charAt(3));
    }
 
    /**
     * Tests that charAt() returns the correct character
     * somewhere in the middle of the string.
     */
    @Test
    public void testCharAtMiddleCharacter() {
        String s = "Programming";
        // 'P','r','o','g' -> index 3 is 'g'
        assertEquals('g', s.charAt(3));
    }
 
    /**
     * Tests that charAt() throws StringIndexOutOfBoundsException
     * when a negative index is used.
     */
    @Test(expected = StringIndexOutOfBoundsException.class)
    public void testCharAtNegativeIndex() {
        String s = "Hello";
        s.charAt(-1); // should throw exception
    }
 
    // -------------------------------------------------------
    // Tests for substring()
    // -------------------------------------------------------
 
    /**
     * Tests that substring(beginIndex) returns the correct portion
     * of the string starting at the given index.
     */
    @Test
    public void testSubstringFromIndex() {
        String s = "HelloWorld";
        assertEquals("World", s.substring(5));
    }
 
    /**
     * Tests that substring(beginIndex, endIndex) returns the correct
     * portion of the string between two indexes.
     */
    @Test
    public void testSubstringWithBeginAndEnd() {
        String s = "HelloWorld";
        assertEquals("World", s.substring(5, 10));
    }
 
    /**
     * Tests that substring() with index 0 returns the whole string.
     */
    @Test
    public void testSubstringFromZero() {
        String s = "Hello";
        assertEquals("Hello", s.substring(0));
    }
 
    /**
     * Tests that substring() returns an empty string when begin
     * and end index are the same.
     */
    @Test
    public void testSubstringEmptyResult() {
        String s = "Hello";
        assertEquals("", s.substring(3, 3));
    }
 
    // -------------------------------------------------------
    // Tests for indexOf()
    // -------------------------------------------------------
 
    /**
     * Tests that indexOf() returns the correct index of a character
     * that exists in the string.
     */
    @Test
    public void testIndexOfCharacterFound() {
        String s = "Hello";
        assertEquals(1, s.indexOf('e'));
    }
 
    /**
     * Tests that indexOf() returns -1 when the character is not
     * found in the string.
     */
    @Test
    public void testIndexOfCharacterNotFound() {
        String s = "Hello";
        assertEquals(-1, s.indexOf('z'));
    }
 
    /**
     * Tests that indexOf() returns the index of the first occurrence
     * when a character appears multiple times.
     */
    @Test
    public void testIndexOfFirstOccurrence() {
        String s = "programming";
        // 'g' appears at index 3 and index 9
        assertEquals(3, s.indexOf('g'));
    }
 
    /**
     * Tests that indexOf() can find a substring inside a larger string.
     */
    @Test
    public void testIndexOfSubstring() {
        String s = "Hello World";
        assertEquals(6, s.indexOf("World"));
    }
 
    /**
     * Tests that indexOf() returns -1 when searching for a substring
     * that does not exist.
     */
    @Test
    public void testIndexOfSubstringNotFound() {
        String s = "Hello World";
        assertEquals(-1, s.indexOf("Java"));
    }
}