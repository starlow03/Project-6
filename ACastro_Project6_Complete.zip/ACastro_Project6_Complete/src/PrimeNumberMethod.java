/**
 * Class provides a utility method to check whether
 * a given integer is a prime number.
 *
 */
public class PrimeNumberMethod {
 
    /**
     * Determines whether the given number is a prime number.
     *
     * <p>The method checks divisibility starting from 2 up to
     * the square root of the number. If any divisor is found,
     * the number is not prime.</p>
     *
     * @param number the integer to test for primality
     * @return {@code true} if the number is prime,
     *         {@code false} otherwise
     */
    public static boolean isPrime(int number) {
        
        if (number <= 1) {
            return false;
        }
 
       
        for (int divisor = 2; divisor <= Math.sqrt(number); divisor++) {
            if (number % divisor == 0) {
                return false; 
            }
        }
 
        return true; 
    }
}