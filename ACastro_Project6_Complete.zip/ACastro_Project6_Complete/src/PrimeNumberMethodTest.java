import org.junit.Test;
import static org.junit.Assert.*;
 
/**
 * This class tests the {@code isPrime} method found in
 * the {@link PrimeNumberMethod} class.
 */
public class PrimeNumberMethodTest {
 
    // Tests for known prime numbers
    
    /**
     * Tests that 2 is correctly identified as a prime number.
     * 2 is the smallest and only even prime number.
     */
    @Test
    public void testIsPrimeTwoIsAPrime() {
        assertTrue(PrimeNumberMethod.isPrime(2));
    }
 
    /**
     * Tests that 3 is correctly identified as a prime number.
     */
    @Test
    public void testIsPrimeThreeIsAPrime() {
        assertTrue(PrimeNumberMethod.isPrime(3));
    }
 
    /**
     * Tests that 7 is correctly identified as a prime number.
     */
    @Test
    public void testIsPrimeSevenIsAPrime() {
        assertTrue(PrimeNumberMethod.isPrime(7));
    }
 
    /**
     * Tests that 13 is correctly identified as a prime number.
     */
    @Test
    public void testIsPrimeThirteenIsAPrime() {
        assertTrue(PrimeNumberMethod.isPrime(13));
    }
 
    /**
     * Tests that 97 is correctly identified as a prime number.
     * This checks that the method works for larger primes too.
     */
    @Test
    public void testIsPrimeLargePrime() {
        assertTrue(PrimeNumberMethod.isPrime(97));
    }
 
    // -------------------------------------------------------
    // Tests for known non-prime (composite) numbers
    // -------------------------------------------------------
 
    /**
     * Tests that 4 is correctly identified as NOT prime.
     * 4 is divisible by 2.
     */
    @Test
    public void testIsPrimeFourIsNotPrime() {
        assertFalse(PrimeNumberMethod.isPrime(4));
    }
 
    /**
     * Tests that 6 is correctly identified as NOT prime.
     * 6 is divisible by 2 and 3.
     */
    @Test
    public void testIsPrimeSixIsNotPrime() {
        assertFalse(PrimeNumberMethod.isPrime(6));
    }
 
    /**
     * Tests that 9 is correctly identified as NOT prime.
     * 9 is divisible by 3.
     */
    @Test
    public void testIsPrimeNineIsNotPrime() {
        assertFalse(PrimeNumberMethod.isPrime(9));
    }
 
    /**
     * Tests that 100 is correctly identified as NOT prime.
     * 100 is divisible by 2, 4, 5, 10, 20, 25, and 50.
     */
    @Test
    public void testIsPrimeLargeCompositeNumber() {
        assertFalse(PrimeNumberMethod.isPrime(100));
    }
 
    // -------------------------------------------------------
    // Edge case tests
    // -------------------------------------------------------
 
    /**
     * Tests that 1 is correctly identified as NOT prime.
     * By definition, 1 is not considered a prime number.
     */
    @Test
    public void testIsPrimeOneIsNotPrime() {
        assertFalse(PrimeNumberMethod.isPrime(1));
    }
 
    /**
     * Tests that 0 is correctly identified as NOT prime.
     * Zero is not a prime number.
     */
    @Test
    public void testIsPrimeZeroIsNotPrime() {
        assertFalse(PrimeNumberMethod.isPrime(0));
    }
 
    /**
     * Tests that a negative number is correctly identified as NOT prime.
     * Negative numbers cannot be prime numbers.
     */
    @Test
    public void testIsPrimeNegativeNumberIsNotPrime() {
        assertFalse(PrimeNumberMethod.isPrime(-5));
    }
 
    /**
     * Tests that -1 is correctly identified as NOT prime.
     */
    @Test
    public void testIsPrimeNegativeOneIsNotPrime() {
        assertFalse(PrimeNumberMethod.isPrime(-1));
    }
}